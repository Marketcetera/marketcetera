# this is a dummy file for those apps (like RubyGems) that explicitly require 'yaml/syck'
