package org.jruby.ext.posix;

public interface WindowsLibC extends POSIX {
}
