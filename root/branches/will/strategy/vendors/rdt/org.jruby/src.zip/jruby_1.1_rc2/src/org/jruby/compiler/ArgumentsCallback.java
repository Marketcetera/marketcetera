/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.jruby.compiler;

/**
 *
 * @author headius
 */
public interface ArgumentsCallback extends CompilerCallback {
    public int getArity();
}
